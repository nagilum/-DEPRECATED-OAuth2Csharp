﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class auth : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
		var clientID = "put-your-client-id-from-facebook-here";
		var clientSecret = "put-your-client-secret-from-facebook-here";
		var provider = "facebook";

		var oauth = new OAuth2(
			clientID,
			clientSecret,
			provider);

		oauth.HandleResponse();

	    this.ltInfo.Text = (oauth.IsAuthorized ? "Success" : "Failure");
    }
}