﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
    }

	protected void btLoginWithFacebook_Click(object sender, EventArgs e) {
		var clientID = "put-your-client-id-from-facebook-here";
		var clientSecret = "put-your-client-secret-from-facebook-here";
		var provider = "facebook";
		var redirectURL =
			Request.Url.Scheme + "://" +
			Request.Url.Authority + "/auth.aspx";

		var oauth = new OAuth2(
			clientID,
			clientSecret,
			provider,
			redirectURL);

		oauth.Authenticate();
	}
}